<?php
/**
 * Global settings/Elements.
 * PHP version 5
 * 
 * @category Components
 * @package  PHP
 * @author   Md Ismail <mi0718839@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-3.0.txt GNU/GPLv3
 * @version  SVN: $Id$
 * @link     https://yoursite.com
 */
$title = "Home";
require "header.php";

// $arr = array();

// if (isset($_SESSION['data'])) {

//     $arr = $_SESSION['data'];
    

// }
// if (isset($arr['name'])) {
//     echo "<h3>welcome '".$arr['name']."'</h3>";
//     echo "<a href='http://localhost/Training/Online_test/login.php?action=logout'>Logout </a>";
// }
?>
<h1>My Test Website:</h1>
<ul id="home">
<li><a href="http://localhost/Training/Online_test/login.php">Please Select an Option Login or click here If you already registerd on this website</a></li>
<li><a href="http://localhost/Training/Online_test/register.php">Please Select an Option Register or click here  If you are new on this website</a></li>
</ul>
<?php
require "footer.php";
?>