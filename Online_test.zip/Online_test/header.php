<?php
/**
 * Header File.
 * PHP version 5
 * 
 * @category Components
 * @package  PHP
 * @author   Md Ismail <mi0718839@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-3.0.txt GNU/GPLv3
 * @version  SVN: $Id$
 * @link     https://yoursite.com
 */
session_start();
require "config.php";
if (isset($_GET['action']) && ($_GET['action'] == 'logout')) {
    session_unset();
    session_destroy();
}
if (isset($_POST['submit']) && $_POST['name'] == "Physics") {
    $_SESSION['data']['cat_name'] = $_POST['name'];
    $select1 = "SELECT * FROM Physics" ; 
    $result1 = mysqli_query($con, $select1);
    $row1 = mysqli_fetch_all($result1, MYSQLI_ASSOC);
    $_SESSION['data']['row'] = $row1;
} elseif (isset($_POST['submit']) && $_POST['name'] == "Chemistry") {
    $_SESSION['data']['cat_name'] = $_POST['name'];
    $select1 = "SELECT * FROM Chemistry" ; 
    $result1 = mysqli_query($con, $select1);
    $row1 = mysqli_fetch_all($result1, MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>
        <?php echo $title; ?>
    </title>
    <link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>
    <div id="header">
        <h1 id="logo">Logo</h1>
        <nav>
            <ul id="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">SignUp</a></li>
            </ul>
        </nav>
    </div>
    <div id="main">