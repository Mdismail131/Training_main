<?php
/**
 * Header File.
 * PHP version 5
 * 
 * @category Components
 * @package  PHP
 * @author   Md Ismail <mi0718839@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-3.0.txt GNU/GPLv3
 * @version  SVN: $Id$
 * @link     https://yoursite.com
 */
$title = "Test";
require "header.php";
if (!isset($_SESSION['data'])) {

    header('Location: http://localhost/Training/Online_test/login.php');

}
$arr = array();

if (isset($_SESSION['data'])) {

    $arr = $_SESSION['data'];
    

}
echo "<h3>welcome '".$arr['name']."' you can quit this ".$_SESSION['data']['cat_name']."      test any time by pressing this logout link  <a href='http://localhost/Training/Online_test/login.php?action=logout'>Logout </a></h3>";

?>
<div class="result">
    <p>Question:</p>
    <p style="text-align: center;"><?php echo $_SESSION['data']['row'][1]['question']; ?></p>
    <div class="table">
        <table>
            <tr>
                <td><input type="radio" name="chA"><?php echo $_SESSION['data']['row'][1]['chA']; ?></td>
                <td><input type="radio" name="chA"><?php echo $_SESSION['data']['row'][1]['chB']; ?></td>
            </tr>
            <tr>
                <td><input type="radio" name="chA"><?php echo $_SESSION['data']['row'][1]['chC']; ?></td>
                <td><input type="radio" name="chA"><?php echo $_SESSION['data']['row'][1]['chD']; ?></td>
            </tr>
        </table>
    </div>
</div>